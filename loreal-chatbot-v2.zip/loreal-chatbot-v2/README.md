# L’Oréal Routine Builder — v2

A lightweight demo you can host on **GitHub Pages** with an API proxy on **Cloudflare Workers** to keep your OpenAI key off the client.

## Repo structure

```
/assets/loreal-logo.png
/cloudflare/worker.js
/data/products.json
index.html
styles.css
script.js
wrangler.toml
```

## Quick start (GitHub Pages)

1. **Create a new repo** and push this folder.
2. In GitHub: **Settings → Pages → Deploy from branch**, choose `main` and `/ (root)` or `/docs` if you move files accordingly.
3. Your site will be at `https://<user>.github.io/<repo>/`.

> Client code calls `WORKER_URL = '/api/chat'` — you should map your Worker to the same domain with a route, or change `WORKER_URL` to the Worker’s full URL.

## Cloudflare Worker

1. Install `wrangler` and log in:  
   ```bash
   npm i -g wrangler
   wrangler login
   ```
2. From repo root, set your secret and publish:
   ```bash
   wrangler secret put OPENAI_API_KEY
   wrangler publish
   ```
3. In Cloudflare dashboard, set a **Route** for the Worker (e.g., `https://yourdomain.com/api/chat`). If using GitHub Pages default domain, you can also use the Worker’s unique URL and update `WORKER_URL` in `script.js`.

### Worker contract

- **POST /api/chat** with body:
  ```json
  { "messages": [{ "role": "user", "content": "..." }] }
  ```
- Returns **OpenAI chat** response shape, e.g.:
  ```json
  { "choices": [ { "message": { "role": "assistant", "content": "..." } } ] }
  ```

## Features

- Tabbed UI: Chat • Browse • My Routine
- Product filter (category/concern/text)
- Routine builder (AM/PM) with localStorage persistence
- Assistant can add items via hints like `[ADD id=sk-spf50]`
- Export routine as `routine.json`

## Customization

- Replace `/data/products.json` with a larger catalog (keep `id`, `name`, `category`, `steps`).
- Update colors in `styles.css` (look for CSS variables in `:root`).
- For separate environments, set `WORKER_URL` in `script.js` to your absolute Worker URL.

## Notes

- This is a demo and not medical advice.
- Do not expose your OpenAI API key on the client — keep it in the Worker.
